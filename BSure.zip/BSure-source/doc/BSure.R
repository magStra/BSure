## ---- echo=FALSE, results="hide", message=FALSE-------------------------------
require(knitr)
opts_chunk$set(error=FALSE, message=FALSE, warning=FALSE)

## ----warnings=F,message=F-----------------------------------------------------
library(BSure)

## ----warnings=F,message=F-----------------------------------------------------
data(counts_HT29_small)

## ----warnings=F,message=F-----------------------------------------------------
colnames(HT29_small)
#The last column is the control measurement. The first column contains the gRNAs
#and the second the names of the corresponding genes.
nc <- ncol(HT29_small)
counts <- HT29_small[,-c(1:2,nc)]#removing columns of gRNAs, genes and controls
controls <- HT29_small[,nc]
lfc_small <- compute_lfc_from_counts(counts=counts, controls=controls)
HT29_lfc_small <- cbind(HT29_small$sgRNA,HT29_small$gene,lfc_small)#required format
#for BSure algorithm:
#first column: gRNAs, second column: corresponding genes, third to last column: 
#log-fold changes for all replicates

## ----warnings=F,message=F,eval=F----------------------------------------------
#  runBSure(lfc=HT29_lfc_small,save_file_name="HT29_lfc_small",n_cores=2,min_tail_ESS=500)

## ----warnings=F,message=F-----------------------------------------------------
load("HT29_lfc_small.rda")#save_file_name from above plus ".rda"
extracted_output_HT29 <- extract_from_output(output)
plot_credible_intervals(extracted_output_HT29,"HT29_small")

## ----warnings=F,message=F-----------------------------------------------------
genes_HT29_small <- unique(HT29_lfc_small[,2])
runBSure(lfc=HT29_lfc_small,save_file_name="HT29_lfc_small_sub",n_cores=2,min_tail_ESS=500,vector_of_genes=genes_HT29_small[seq(1,length(genes_HT29_small),10)],plot_folder_name="HT29_small_gene_distributions")

## ----eval=F-------------------------------------------------------------------
#  library(BSure)
#  nCores <- 25
#  data("counts_HT29")
#  dir.create("results_HT29")
#  nc <- ncol(counts_HT29)
#  lfc <- cbind(counts_HT29[,1:2],compute_lfc_from_counts(counts_HT29[,-c(1:2,nc)],counts_HT29[,nc]))
#  save_file_name <- "results_HT29/HT29_full"
#  runBSure(lfc,save_file_name,nCores,2000)
#  load(paste(save_file_name,".rda",sep=""))
#  extracted_output <- extract_from_output(output)
#  save(extracted_output,file=paste0(save_file_name,"_extracted_output.rda"))
#  plot_credible_intervals(extracted_output,"results_HT29")

## ----warnings=F,message=F,out.width = "80%"-----------------------------------
data("HT29_full_extracted_output")
extracted_gene_categories_HT29 <- extract_gene_categories(HT29_full_extracted_output)
extracted_gene_categories_HT29$proportion_core_essential_in_essential_II
extracted_gene_categories_HT29$proportion_core_essential_in_essential_I
extracted_gene_categories_HT29$proportion_non_essential_genes_in_essential_II
extracted_gene_categories_HT29$proportion_non_essential_genes_in_essential_I
extracted_gene_categories_HT29$score

## ----warnings=F,message=F,out.width = "80%"-----------------------------------
data("HT29_full_extracted_output")
extracted_gene_categories_HT29_strict <- extract_gene_categories(HT29_full_extracted_output,10^-4)
extracted_gene_categories_HT29_strict$proportion_core_essential_in_essential_II
extracted_gene_categories_HT29_strict$proportion_core_essential_in_essential_I
extracted_gene_categories_HT29_strict$proportion_non_essential_genes_in_essential_II
extracted_gene_categories_HT29_strict$proportion_non_essential_genes_in_essential_I
extracted_gene_categories_HT29_strict$score

## ----warnings=F,message=F-----------------------------------------------------
data("resultsK562_highest_extracted_output") #screens with highest experiment coverage levels (160x-180x), lower Cas9 activity, 3' readout
data("resultsK562_high_extracted_output") #120x-130x experiment coverage levels, lower Cas9 activity, 3' readout
data("resultsK562_lowest_extracted_output") #25x-30x experiment coverage levels, lower Cas9 activity, 3' readout
data("resultsK562_highCas9_extracted_output")#higher Cas9 activity, 134x coverage, 3' and 5' readout

## ----warnings=F,message=F-----------------------------------------------------
extracted_gene_categories_K562_best <- extract_gene_categories(resultsK562_highCas9_extracted_output)
extracted_gene_categories_K562_best$proportion_core_essential_in_essential_II
extracted_gene_categories_K562_best$proportion_core_essential_in_essential_I
extracted_gene_categories_K562_best$proportion_non_essential_genes_in_essential_II
extracted_gene_categories_K562_best$proportion_non_essential_genes_in_essential_I
extracted_gene_categories_K562_best$score

## -----------------------------------------------------------------------------
extracted_gene_categories_K562_highest<- extract_gene_categories(resultsK562_highest_extracted_output)
extracted_gene_categories_K562_highest$proportion_core_essential_in_essential_II
extracted_gene_categories_K562_highest$proportion_core_essential_in_essential_I
extracted_gene_categories_K562_highest$proportion_non_essential_genes_in_essential_II
extracted_gene_categories_K562_highest$proportion_non_essential_genes_in_essential_I
extracted_gene_categories_K562_highest$score

## -----------------------------------------------------------------------------
comparison_Cas9_K562 <- compare_to_exisiting_screen(gene_set_new_screen=extracted_gene_categories_K562_highest$essential_genes_II,extracted_gene_categories_K562_best$essential_genes_II,extracted_gene_categories_K562_best$false_positive_rate_essential_II,extracted_gene_categories_K562_best$false_negative_rate_essential_II)
comparison_Cas9_K562

## ----warnings=F,message=F,out.width = "70%"-----------------------------------
comparison_highest_lowest <- compare_length_of_credible_intervals(resultsK562_highest_extracted_output,resultsK562_lowest_extracted_output, "160x-180x","25x-30x")
comparison_highest_high <- compare_length_of_credible_intervals(resultsK562_highest_extracted_output,resultsK562_high_extracted_output, "160x-180x","120x-130x")

## -----------------------------------------------------------------------------
intersect(extracted_gene_categories_K562_best$not_essential_genes_I,extracted_gene_categories_HT29$essential_genes_II)
extracted_gene_categories_K562_best$false_positive_rate_not_essential_I
extracted_gene_categories_HT29$false_positive_rate_essential_II

## -----------------------------------------------------------------------------
intersect(extracted_gene_categories_K562_best$essential_genes_II,extracted_gene_categories_HT29$not_essential_genes_I)
extracted_gene_categories_K562_best$false_positive_rate_essential_II
extracted_gene_categories_HT29$false_positive_rate_not_essential_I

## ----warnings=F,message=F-----------------------------------------------------
extracted_gene_categories_K562_best_strict <- extract_gene_categories(resultsK562_highCas9_extracted_output,10^-4)

## -----------------------------------------------------------------------------
intersect(extracted_gene_categories_K562_best_strict$not_essential_genes_I,extracted_gene_categories_HT29_strict$essential_genes_II)

## -----------------------------------------------------------------------------
intersect(extracted_gene_categories_K562_best_strict$essential_genes_II,extracted_gene_categories_HT29_strict$not_essential_genes_I)

## -----------------------------------------------------------------------------
sessionInfo()


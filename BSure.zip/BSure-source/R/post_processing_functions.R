#' Extracts core output from the output file created by the BSure function.
#' The extracted output is used in postprocessing functions for plotting and quality control.
#' @param BSure_output  output created by BSure function
#' @title extract_from_output
#' @return sample_summary with mean estimates (mean) and 95% credible intervals (CI_lower_bounds
#' for the lower bounds of the intervals, CI_upper bounds for the upper ones) of the essentiality
#' level of each gene, the probability of a gene being highly essential (prob_essential_II; the posterior distribution
#' of the essentiality being shifted less than 1/3 compared to a typical core-essential gene), the
#' probability of a gene being essential of level I (no overlap with distribution of typical nonessential gene),
#' and convergence statistics (Rhat=Gelman-Rubin R-hat statistic, tail_ESS=tail essential sample size)
#' In addition to the sample summary: prop_expensive_sampling: proportion of genes which
#' required a more expensive sampling algorithm
#' prop_very_expensive_sampling: proportion of genes which required the most expensive sampling
#' algorithm
#' @export
extract_from_output <- function(BSure_output)
{
  ncl <- ncol(BSure_output)
  res <- c()
  Rhat <- rep(0,ncl)
  CI_lower_bounds <- rep(0,ncl)
  CI_upper_bounds <- rep(0,ncl)
  prob_essential_I <- rep(0,ncl)
  prob_essential_II <- rep(0,ncl)
  tail_ESS <- rep(0,ncl)
  means <- rep(0,ncl)
  gene_names <- c()
  nExpensiveSampling <- 0
  nVeryExpensiveSampling <- 0
  for (j in 1:ncl)
  {
    Rhat[j] <- BSure_output[,j]$rhat[1]
    nExpensiveSampling = nExpensiveSampling+BSure_output[,j]$expensiveSampling
    nVeryExpensiveSampling = nVeryExpensiveSampling+BSure_output[,j]$veryExpensiveSampling
    CI_lower_bounds[j] <- BSure_output[,j]$quant025[1]
    CI_upper_bounds[j] <- BSure_output[,j]$quant975[1]
    tail_ESS[j] <- BSure_output[,j]$ess_tail[1]
    means[j] <- BSure_output[,j]$mean[1]
    prob_essential_II[j] <- BSure_output[,j]$probability_essential_II
    prob_essential_I[j] <- BSure_output[,j]$probability_essential_I
    gene_names <- c(gene_names,BSure_output[,j]$gene_names)
  }
  prop_expensive_sampling <- nExpensiveSampling/ncl
  prop_very_expensive_sampling <- nVeryExpensiveSampling/ncl
  sample_summary <- data.frame(means=means,CI_lower_bounds=CI_lower_bounds,CI_upper_bounds=CI_upper_bounds,
                              Rhat=Rhat,tail_ESS=tail_ESS,prob_essential_II=prob_essential_II,
                              prob_essential_I=prob_essential_I,gene_names=gene_names)
  res$prop_expensive_sampling <- prop_expensive_sampling
  res$prop_very_expensive_sampling <- prop_very_expensive_sampling
  res$sample_summary <- sample_summary
  return(res)
}

#' This function extracts sets of
#' 1) highly essential genes (essentiality level II, the posterior distribution
#' of the essentiality is shifted less than 1/3 compared to a typical core-essential gene
#' with FDR at most 0.05 and individual probability at least 0.9
#' 2) genes confidently not nonessential with FDR at most 0.05 and
#' individual probability at least 0.9 (essentiality level I)
#' @title extract_gene_categories
#' @import eulerr
#' @param extracted_output output of the function extract_from_output
#' @param FDR set to 0.05 by default; maximum false positive rate for all gene sets
#' @return essential_genes_II highly essential genes of essentiality level II (see above)
#' essential_genes_I genes of essentiality level I (see above), this set should contain almost all of the genes of
#' essentiality level II. If it does not, this indicates poor screen quality.
#' proportion_core_essential_in_essential_II which proportion of core essential genes is in the essential genes
#' II group
#' (as core essential genes we use the intersection of core essential genes from  Hart and Moffat (2016) and
#' Behan et al. (2019))
#' not_essential_genes_II genes that are unessential of type II with a probability with FDR at most 0.05 (unless specified otherwise)
#' and individual probability at least 0.9
#' not_essential_genes_I genes that are unessential of type I with a probability with FDR at most 0.05 (unless specified otherwise)
#' and individual probability at least 0.9
#' proportion_core_essential_in_essential_I proportion of core essential genes in essential I group
#' proportion_non_essential_genes_in_essential_II proportion of nonessential genes in essential II group
#' (nonessential as in Hart and Moffat (2016)); this number should be zero or very close to 0
#' proportion_non_essential_genes_in_essential_I proportion of nonessential genes in essential I group
#' score A summary score for the ability of a screen to separate core essential and nonessential genes.
#' false_negative_rate_essential_II False negative rate for genes essential of type II. This is equal to 0.05 (unless specified otherwise) unless
#' the individual cutoff of a 90% probability of being essential type II for each gene was stricter (see above).
#' false_positive_rate_essential_II False positive rate for genes essential of type II.
#' false_negative_rate_essential_I False negative rate for genes essential of type I. This is equal to 0.05 (unless specified otherwise) unless
#' the individual cutoff of a 90% probability of being essential type I for each gene was stricter (see above).
#' false_positive_rate_essential_I False positive rate for genes essential of type I.
#' false_negative_rate_not_essential_II False negative rate for genes unessential of type II. This is equal to 0.05 (unless specified otherwise) unless
#' the individual cutoff of a 90% probability of being unessential type II for each gene was stricter (see above).
#' false_positive_rate_not_essential_II False positive rate for genes unessential of type II.
#' false_negative_rate_not_essential_I False negative rate for genes unessential of type I. This is equal to 0.05 (unless specified otherwise) unless
#' the individual cutoff of a 90% probability of being unessential type I for each gene was stricter (see above).
#' false_positive_rate_not_essential_I False positive rate for genes unessential of type I.
#'
#' @references Hart T, Moffat J.
#' BAGEL: a computational framework for identifying essential genesfrom pooled library screens.
#' BMC Bioinformatics. 2016;17(1):164.  doi:10.1186/s12859-016-1015-8
#' Behan FM et al. Prioritization of cancer therapeutic targets using CRISPR–Cas9 screens.
#' Nature. 2019;568(7753):511–516
#' @export
extract_gene_categories <- function(extracted_output,FDR=0.05)
{
  data(auxData)
  coreEssGenes <- intersect(CEGv2,coreFitnessBehanEtAl)
  nonEssGenes <- NEG
  output <- c()
  coreEssGenes <- intersect(coreEssGenes,extracted_output$sample_summary$gene_names)
  nonEssGenes <- intersect(nonEssGenes,extracted_output$sample_summary$gene_names)
  probs_essential_II <- extracted_output$sample_summary$prob_essential_II
  alpha0 <- max(0.9,.findOptimalAlpha(probs_essential_II,FDR))
  probs_essential_I <- extracted_output$sample_summary$prob_essential_I
  alpha1 <- max(0.9,.findOptimalAlpha(probs_essential_I,FDR))
  probs_not_essential_II <- 1- probs_essential_II
  probs_not_essential_I <- 1- probs_essential_I
  alpha2 <- max(0.9,.findOptimalAlpha(probs_not_essential_II,FDR))
  alpha3 <- max(0.9,.findOptimalAlpha(probs_not_essential_I,FDR))
  output$essential_genes_II<- extracted_output$sample_summary$gene_names[probs_essential_II>alpha0]
  output$essential_genes_I <- extracted_output$sample_summary$gene_names[probs_essential_I>alpha1]
  output$not_essential_genes_II<- extracted_output$sample_summary$gene_names[probs_essential_II>alpha2]
  output$not_essential_genes_I <- extracted_output$sample_summary$gene_names[probs_essential_I>alpha3]
  coreEssGenesDiscovered <- intersect(output$essential_genes_II,coreEssGenes)
  coreEssGenesDiscoveredNotNE <- intersect(output$essential_genes_I,coreEssGenes)
  output$proportion_core_essential_in_essential_II <- length(coreEssGenesDiscovered)/length(coreEssGenes)
  output$proportion_core_essential_in_essential_I <- length(coreEssGenesDiscoveredNotNE)/length(coreEssGenes)
  non_essential_genes_in_essential_II <- intersect(output$essential_genes_II,nonEssGenes)
  non_essential_genes_in_essential_I <- intersect(output$essential_genes_I,nonEssGenes)
  output$proportion_non_essential_genes_in_essential_II <- length(non_essential_genes_in_essential_II)/length(nonEssGenes)
  output$proportion_non_essential_genes_in_essential_I <- length(non_essential_genes_in_essential_I)/length(nonEssGenes)
  gene_set_list <- list(output$essential_genes_II,coreEssGenes,nonEssGenes)
  names_set <- c("essential (II)",
                 "core essential genes",
                 "nonessential genes")
  names(gene_set_list) <- names_set
  print(.plot_Venn_diagram(gene_set_list))
  gene_set_list <- list(output$essential_genes_I,coreEssGenes,nonEssGenes)
  names_set <- c("essential (I)",
                 "core essential genes",
                 "nonessential genes")
  names(gene_set_list) <- names_set
  print(.plot_Venn_diagram(gene_set_list))
  gene_set_list <- list(output$essential_genes_I,output$essential_genes_II)
  names_set <- c("essential (II)","essential (I)")
  names(gene_set_list) <- names_set
  print(.plot_Venn_diagram(gene_set_list))
  output$score <- sqrt(output$proportion_core_essential_in_essential_II*output$proportion_core_essential_in_essential_I)-
    output$proportion_non_essential_genes_in_essential_I
  output$false_negative_rate_essential_II <- .false_negative_rate(probs_essential_II,alpha0)
  output$false_positive_rate_essential_II <- .false_positive_rate(probs_essential_II,alpha0)
  output$false_negative_rate_essential_I <- .false_negative_rate(probs_essential_I,alpha1)
  output$false_positive_rate_essential_I <- .false_positive_rate(probs_essential_I,alpha1)
  output$false_negative_rate_not_essential_II <- .false_negative_rate(probs_not_essential_II,alpha2)
  output$false_positive_rate_not_essential_II <- .false_positive_rate(probs_not_essential_II,alpha2)
  output$false_negative_rate_not_essential_I <- .false_negative_rate(probs_not_essential_II,alpha3)
  output$false_positive_rate_not_essential_I <- .false_positive_rate(probs_not_essential_II,alpha3)
  return(output)
}


library(RColorBrewer)

.false_positive_rate <- function(probs,alpha)
{
  return(sum((1-probs)*(probs>alpha))/sum(probs>alpha))
}

.false_negative_rate <- function(probs,alpha)
{
  return(sum(probs*(probs<=alpha))/sum(probs<=alpha))
}

#' @import rootSolve
.findOptimalAlpha <- function(probs,FDR=0.05)
{ return(uniroot(function(alpha) return(.false_positive_rate(probs,alpha)-FDR),c(min(probs)+10^-10,sort(probs,decreasing=T)[2]-10^-10))$root)}

#' @import eulerr
.plot_Venn_diagram <- function(gene_set_list,file_name,res=1200)
{
  p <- plot(euler(gene_set_list, shape = "ellipse"), quantities = TRUE,adjust_labels=TRUE)
  return(p)

}

#' @title compare_to_exisiting_screen
#' Compares a new screen to your gold-standard screen. For example, your gold-standard screen may be of high
#' coverage and your new screen of lower coverage, and you want to check whether essential genes of type I or II
#' from the gold standard screen are also recovered by the new screen. The function takes into account false
#' positive and false negative rates for the gold standard.
#' @params gene_set_new_screen Set of essential genes of type I or II from new screen, computed using the function
#' extract_gene_categories.
#' gene_set_gold_standard Set of essential genes of type I or II from gold standard.
#' false_positive_rate_gold_standard False positive rate for gene set from gold standard.
#' false_negative_rate_gold_standard False negative rate for gene set from gold standard.
#' @return proportion_genes_recovered Proportion of genes from gene_set_gold_standard that is recovered in the new
#' screen, accounting for false positives in the gold standard screen
#' proportion_genes_not_in_gold_standard_set Proportion of genes from gene_set_new_screen that are not in gene_set_gold_standard,
#' accounting for false negatives in the gold standard screen
#' @export

compare_to_exisiting_screen <- function(gene_set_new_screen,gene_set_gold_standard,false_positive_rate_gold_standard,
                                     false_negative_rate_gold_standard)
{
  output <- c()
  output$proportion_genes_recovered <- min(1,length(intersect(gene_set_new_screen,gene_set_gold_standard))/(
    length(gene_set_gold_standard)*(1-false_positive_rate_gold_standard)))

  output$proportion_genes_not_in_gold_standard_set <-  min(1,length(setdiff(gene_set_new_screen,gene_set_gold_standard))/
    length(gene_set_new_screen)*(1-false_negative_rate_gold_standard))
  return(output)
}

#' @title compare_length_of_credible_intervals
#' Compares the length of the credible intervals of the gene essentiality estimates for two different screens or
#' studies.
#' @param extracted_output_1 extracted output for screen/study 1, computed from BSure output using the function
#' extract_from_output.
#' @param extracted_output_2 extracted output for screen/study 2, computed from BSure output using the function
#' extract_from_output.
#' @param study_name_1 name of first screen/study
#' @param study_name_2 name of second screen/study
#' @return ratio of credible intervals, prints scatterplot comparing lengths of credible intervals.
#' @export

compare_length_of_credible_intervals <- function(extracted_output_1,extracted_output_2,study_name_1,study_name_2)
{
  CIs_1 <- extracted_output_1$sample_summary$CI_upper_bounds -
    extracted_output_1$sample_summary$CI_lower_bounds
  CIs_2 <- extracted_output_2$sample_summary$CI_upper_bounds -
    extracted_output_2$sample_summary$CI_lower_bounds
  df <- data.frame(CIs_1=CIs_1,CIs_2=CIs_2)
  pp <- ggplot(df,aes(y=CIs_1,x=CIs_2)) + geom_point(alpha=0.05,size=1,color="blue")+
    ylab(study_name_1)+xlab(study_name_2)+theme_classic()+theme(axis.text.x = element_text(size=15),
                                                            axis.text.y = element_text(size=15),axis.title.x = element_text(size=20),
                                                            axis.title.y=element_text(size=20),plot.title = element_text(size=20))+
    ggtitle("length of credible interval")+ geom_abline(aes(intercept = 0, slope = 1),
                                                     color="black",linetype = "dashed",size=1.2,show.legend = T)
  print(pp,width=8.8/2.54)
  output <- cbind(CIs_1,CIs_2/CIs_1)
  colnames(output) <- c("study 1","study 2/study 1")
  return(cbind(CIs_1,CIs_2/CIs_1))
}
#'
#'
#'
#'
#'
#'
#' @title plot_credible_intervals
#' @import ggplot2
#' @import ggthemes
#' @param extracted_output output of the function extract_from_output
#' @param name name of the screen for naming of output folder and pdf files
#' @return creates pdf files with the following plots:
#' 1) credible_intervals_as_function_of_mean: credible intervals of essentiality estimates along y-axis,
#' mean of essentality estimates on x-axis
#' 2) credible_intervals_ordered_by_mean: credible intervals of essentiality estimates along y-axis,
#' ordered by mean of essentiality estimates (ordered along x-axis)
#' 3) density_length_of_credible_interval: density distribution of the lengths of the credible intervals
#' 4) tail_ESS_credible_interval and Rhat_credible_interval: diagnostic plots to identify any correlation
#' between convergence measures and the lengths of credible intervals. If there is correlation (which is rare)
#' this may point to convergence problems of the sampler, and the results may be less reliable.
#' @export
plot_credible_intervals <- function(extracted_output,name)
{
  dir.create(paste0(name,"/"))
  name <- paste0(name,"/",name)
  mu <- extracted_output$sample_summary$means
  names(mu) <- extracted_output$gene_names
  minCredInt <- extracted_output$sample_summary$CI_lower_bounds
  names(minCredInt) <- extracted_output$gene_names
  maxCredInt <- extracted_output$sample_summary$CI_upper_bounds
  names(maxCredInt) <- extracted_output$gene_names
  tail_ESS <-  extracted_output$sample_summary$tail_ESS
  names(tail_ESS) <- extracted_output$gene_names
  Rhat <- extracted_output$sample_summary$Rhat
  names(Rhat) <- extracted_output$gene_names
  aa <- order(mu)
  boundCredInt <- c(minCredInt[aa],maxCredInt[aa])
  postMean <- c(mu[aa],mu[aa])
  minMaxInd <- rep(c("lower","upper bound"),each=length(mu))
  df <- data.frame(postMean=postMean,boundCredInt = boundCredInt, minMaxInd=minMaxInd)
  pp<-ggplot(df, aes(x=postMean,y=boundCredInt)) +
    geom_line(aes(color = minMaxInd)) +
    theme_bw(base_size = 11)+xlab("posterior mean")+
    ylab("95% credible intervals")+scale_color_colorblind()+theme(legend.title = element_blank(),
                                                               legend.position = "top",legend.text = element_text(size=13),legend.title.align = 0)
  pdf(file=paste(name,"_credible_intervals_as_function_of_mean.pdf",sep=""),width=unit(3.5,"cm"),height=unit(2.5,"cm"))
  print(pp,dpi=1200)
  dev.off()
  ordering = rep(1:length(aa),2)
  df <- data.frame(ordering=ordering,boundCredInt = boundCredInt, minMaxInd=minMaxInd)
  pp<-ggplot(df, aes(x=ordering,y=boundCredInt)) +
    geom_line(aes(color = minMaxInd)) +
    theme_bw(base_size = 11)+xlab("rank of mean essentiality")+
    ylab("95% credible intervals")+scale_color_colorblind()+theme(legend.title = element_blank(),
                                                               legend.position = "top",legend.text = element_text(size=13),legend.title.align = 0)
  pdf(file=paste(name,"_credible_intervals_ordered_by_mean.pdf",sep=""),width=unit(3.5,"cm"),height=unit(2.5,"cm"))
  print(pp,dpi=1200)
  dev.off()
  lengthCredInt <- maxCredInt-minCredInt
  df <- data.frame(lengthCredInt=lengthCredInt)
  pp<-ggplot(df,aes(x=lengthCredInt)) + geom_density(position=position_stack(vjust=0.5))+theme_classic(base_size = 11)+xlab("Length of credible interval")+
    ylab("number of genes")+geom_rug(color="blue",alpha=0.1)+theme(axis.text.x = element_text(size=11),
             axis.text.y = element_text(size=11))
  pdf(file=paste(name,"_density_length_of_credible_interval.pdf",sep=""),width=unit(4,"cm"),height=unit(2.5,"cm"))
  print(pp,dpi=1200)
  dev.off()
  df <- data.frame(tail_ESS=tail_ESS,lengthCredInt=lengthCredInt)
  pp <- ggplot(df,aes(x=tail_ESS,y=lengthCredInt))+geom_point()+xlab("tail ESS")+ylab("length of 95%\n credible interval")+theme_classic(base_size = 11)+
    theme(axis.text.x = element_text(size=11), axis.text.y = element_text(size=11))
  pdf(file=paste(name,"_tail_ESS_credible_interval.pdf",sep=""),width=unit(4,"cm"),height=unit(2.5,"cm"))
  print(pp,dpi=1200)
  dev.off()
  df <- data.frame(Rhat=Rhat,lengthCredInt=lengthCredInt)
  pp <- ggplot(df,aes(x=Rhat,y=lengthCredInt))+geom_point()+xlab("R-hat")+ylab("length of 95%\n credible interval")+theme_classic(base_size = 11)+
    theme(axis.text.x = element_text(size=11), axis.text.y = element_text(size=11))
  pdf(file=paste(name,"_Rhat_credible_interval.pdf",sep=""),width=unit(4,"cm"),height=unit(2.5,"cm"))
  print(pp,dpi=1200)
  dev.off()
}
#'
#'
#' technical_replicate_correlations_essential <- function(lfc,plotTitle="")
#' {
#'   l <- floor(nrow(lfc)*0.1)
#'   xx <- complete.cases(lfc)
#'   A <- lfc[xx,-(1:2)]
#'   x1 <- order(rowMeans(A),decreasing = F)[1:l]
#'   corMatrix <- cor(A[x1,])
#'   melted_corMatrix <- melt(corMatrix)
#'   pRepCor <- ggplot(data = melted_corMatrix, aes(x=Var1, y=Var2, fill=value)) +
#'     geom_tile()+theme_minimal()+scale_fill_gradient(name="Correlation\n of log-fold changes\n 20% most depleted")+
#'     theme(legend.key.height = unit(0.4, "cm"),legend.text=element_text(size=14),axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1,size=12),
#'           legend.title = element_text(size=18),axis.title = element_text(size=14),plot.title=element_text(size=14),axis.text.y = element_text(size=12)) +
#'     ylab("")+xlab("")+ ggtitle(plotTitle)
#'   output <- c()
#'   output$correlation_matrix <- corMatrix
#'   output$plot <- pRepCor
#'   output$meanCorrelation <- mean(corMatrix[upper.tri(corMatrix)])
#'   return(output)
#' }
#'
#' technical_replicate_correlations <- function(lfc,plotTitle="")
#' {
#'   #compute a score so that we can compare this across screens
#'   #and make plots
#'   lfc1 <- lfc[complete.cases(lfc[,-(1:2)]),-c(1:2)]
#'   corMatrix <- cor(lfc1)
#'   melted_corMatrix <- melt(corMatrix)
#'   pRepCor <- ggplot(data = melted_corMatrix, aes(x=Var1, y=Var2, fill=value)) +
#'     geom_tile()+theme_minimal()+scale_fill_gradient(name="Correlation\n of log-fold changes")+
#'     theme(legend.key.height = unit(0.4, "cm"),legend.text=element_text(size=14),axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1,size=12),
#'           legend.title = element_text(size=18),axis.title = element_text(size=14),plot.title=element_text(size=14),axis.text.y = element_text(size=12)) +
#'     ylab("")+xlab("")+ ggtitle(plotTitle)
#'   output <- c()
#'   output$correlation_matrix <- corMatrix
#'   output$plot <- pRepCor
#'   output$meanCorrelation <- mean(corMatrix[upper.tri(corMatrix)])
#'   return(output)
#' }
#'
#' biological_replicate_correlations <- function(lfcRep1,lfcRep2)
#' {
#'   xx <- complete.cases(lfcRep1)
#'   xx[!(complete.cases(lfcRep2))] <- F
#'   return(mean(cor(lfcRep1[xx,-(1:2)],lfcRep2[xx,-(1:2)])))
#' }
#'
#' biological_replicate_correlations_essential <- function(lfcRep1,lfcRep2)
#' {
#'   l <- floor(nrow(lfcRep1)*0.2)
#'   xx <- complete.cases(lfcRep1)
#'   xx[!(complete.cases(lfcRep2))] <- F
#'   A <- lfcRep1[xx,-(1:2)]
#'   B <- lfcRep2[xx,-(1:2)]
#'   x1 <- order(rowMeans(cbind(A,B)),decreasing = F)[1:l]
#'
#'   cor(A[x1,],B[x1,])
#'   mean(cor(A[x1,],B[x1,]))
#'   return(mean(cor(A[x1,],B[x1,])))
#' }
#'
#'
#'
